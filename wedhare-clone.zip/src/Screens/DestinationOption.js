import React from 'react'
import './DestinationOption.css'

function DestinationOption({source, Icon, destination}) {
    return (
        <div className="destinationOption">
            <h3>{source}</h3>
            {Icon && <Icon className="destinationOption_icon"/>}
            <h3>{destination}</h3>
        </div>
    )
}

export default DestinationOption
